<script lang="ts">
    import {
      Collapse,
      Navbar,
      NavbarToggler,
      NavbarBrand,
      Nav,
      NavItem,
      NavLink,
      Dropdown,
      DropdownToggle,
      DropdownMenu,
      DropdownItem
    } from 'sveltestrap';
    import { onMount } from 'svelte';
    import Ctrecicla from './ctrecicla.svelte';
    import { createEventDispatcher } from 'svelte';

    let isOpen = false;
  
    function handleUpdate(event) {
      isOpen = event.detail.isOpen;
    }

    let currentComponent = null;

    const loadComponent = (component) => {
      currentComponent = component;
    };

    // Load CtReciclaContent component by default
    onMount(() => {
      
      loadComponent(Ctrecicla);
    
    });

    const dispatch = createEventDispatcher();

    const handleClick = () => {
      dispatch('changeContent', { component: 'CtReciclaContent' });
    };

  </script>

  <!-- ======= Mobile nav toggle button ======= -->
  <!-- <button type="button" class="mobile-nav-toggle d-xl-none"><i class="bi bi-list mobile-nav-toggle"></i></button> -->
  <i class="bi bi-list mobile-nav-toggle d-lg-none"></i>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex flex-column justify-content-center">

    <nav id="navbar" class="navbar nav-menu">
      <ul>
        <li>
            <a href="#recctr" class="nav-link scrollto" on:click={() => loadComponent(Ctrecicla)}>
              <img src="icon/rlocalon.png" alt="Localização" class="imagem">
              <span>Centros de Reciclagem</span>
              <i class="bx bx-home"></i>
            </a>
          </li>
        <li>
          <a href="#recicle" class="nav-link scrollto">
            <img src="icon/reciclagem.png" alt="Reciclagem" class="imagem">
            <span>3 R's</span>
            <i class="bx bx-home"></i>
          </a>
        </li>
        <li>
          <a href="#cards" class="nav-link scrollto">
            <img src="icon/cardsoff.png" alt="Cartões" class="imagem">
            <span>Cartões</span>
            <i class="bx bx-home"></i>
          </a>
        </li>
        <li>
          <a href="#ranks" class="nav-link scrollto">
            <img src="icon/rankingoff.png" alt="Ranking" class="imagem">
            <span>Ranking</span>
            <i class="bx bx-home"></i>
          </a>
        </li>
        <li>
          <a href="#acc" class="nav-link scrollto">
            <img src="icon/accoff.png" alt="Conta" class="imagem">
            <span>Utilizador</span>
            <i class="bx bx-home"></i>
          </a>
        </li>
      </ul>
    </nav>
    <!-- .nav-menu -->

    
  </header><!-- End Header -->

  {#if currentComponent}
      <svelte:component this={currentComponent} />
  {/if}

<style>
/*--------------------------------------------------------------
# Disable aos animation delay on mobile devices
--------------------------------------------------------------*/

/*--------------------------------------------------------------
# Navigation Menu
--------------------------------------------------------------*/
/**
* Desktop Navigation 
*/
.nav-menu {
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    list-style: none;
  }

  .nav-menu * {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .nav-menu > ul > li {
    position: relative;
    white-space: nowrap;
  }

  .nav-menu a,
  .nav-menu a:focus {
    display: flex;
    align-items: center;
    color: #45505b;
    padding: 10px 18px;
    margin-bottom: 8px;
    transition: 0.3s;
    font-size: 15px;
    border-radius: 50px;
    background: #f2f3f5;
    height: 56px;
    width: 100%;
    overflow: hidden;
    transition: 0.3s;
  }

  .nav-menu a i,
  .nav-menu a:focus i {
    font-size: 20px;
  }

  .nav-menu a span,
  .nav-menu a:focus span {
    padding: 0 5px 0 7px;
    color: #45505b;
  }

  @media (min-width: 992px) {
    .nav-menu {
      flex-direction: row;
    }

    .nav-menu a,
    .nav-menu a:focus {
      width: 56px;
    }

    .nav-menu li:hover > a {
      width: 240px;
      background: #ff3e00;
      color: #fff;
    }

    .nav-menu a:hover i {
      color: #fff;
    }

    .nav-menu a:hover span {
      color: #fff;
    }

    .nav-menu .drop-down ul {
      top: 56px;
      left: 0;
      padding: 10px 0;
      z-index: 99;
      opacity: 0;
      visibility: hidden;
      background: #fafbfd;
      width: 100%;
      transform: translateY(20px);
      position: absolute;
      transition: 0.3s;
    }

    .nav-menu .drop-down ul a {
      padding: 10px 20px;
      width: 100%;
      height: 48px;
      font-size: 14px;
      text-transform: none;
      color: #45505b;
      background: #fff;
      transition: 0.3s;
    }

    .nav-menu .drop-down ul a:hover {
      background: #ff3e00;
      color: #fff;
    }

    .nav-menu .drop-down ul ul {
      top: 0;
      left: calc(100% - 30px);
    }

    .nav-menu .drop-down .drop-down ul {
      top: 0;
      left: calc(-100% + 30px);
    }

    .nav-menu .drop-down .drop-down ul a {
      padding-left: 30px;
    }

    .nav-menu .drop-down .drop-down .drop-down ul {
      top: 0;
      left: calc(100% - 30px);
    }
  }

  /**
  * Mobile Navigation
  */
  .mobile-nav-toggle {
    position: fixed;
    right: 15px;
    top: 15px;
    z-index: 9998;
    border: 0;
    background: none;
    font-size: 24px;
    transition: all 0.4s;
    outline: none !important;
  }

  .mobile-nav .drop-down ul a {
    padding: 10px;
    font-size: 14px;
  }

  .mobile-nav .drop-down ul a:hover,

  .mobile-nav .drop-down ul li:hover > a {
    color: #ff3e00;
  }

  .imagem{
    display: flex;
    margin-left: auto;
    margin-right: auto;
    
  }
  </style>